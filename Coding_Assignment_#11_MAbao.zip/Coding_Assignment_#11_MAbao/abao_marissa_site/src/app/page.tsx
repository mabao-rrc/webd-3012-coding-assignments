// This is the default Home component for the Next.js app.
// It simply returns an <h1> heading with the text "Codin 1" as required in Assignment 11.
export default function Home() {
  return (
    <h1>Codin 1</h1>
  );
}
